import bcrypt from 'bcrypt';
import pool from '../config/db.js';

class AuthModel {
    // Checks if the email exists in the users table
    static async checkEmailExists(email) {
        const query = 'SELECT id FROM users WHERE email = ?';
        const [rows] = await pool.query(query, [email]);
        return rows[0];
    }

    static async registerStep1(email, password) {
        const query = `
            INSERT INTO pending_registrations (email, password) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE password = ?, created_at = CURRENT_TIMESTAMP
        `;
        const [rows] = await pool.query(query, [email, password, password]);
        return rows;
    }

    static async registerStep2(userData) {
        const { email, password, name, role, phone, profile_image_url, tag_line, bio, city, categoryIds } = userData;

        // Establish an isolated connection from the allocation pool to manage the transaction state
        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            // Retrieving from the temporary table
            const pendingQuery = 'SELECT * FROM pending_registrations WHERE email = ? FOR UPDATE';
            const [pendingRows] = await connection.query(pendingQuery, [email]);
            const pendingData = pendingRows[0];

            if (!pendingData) {
                throw new Error("Temporary registration record missing or expired.");
            }

            // Cross-checking passwords
            let finalPassword = password;
            if (!finalPassword) {
                finalPassword = pendingData.password;
            }

            // Insert core entity row into 'users' table
            const userQuery = `
                INSERT INTO users (name, email, phone, role, profile_image_url, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            `;
            const [userResult] = await connection.query(userQuery, [name, email, phone, role, profile_image_url]);
            const userId = userResult.insertId;

            // Insert the raw plain-text password directly into the secure isolation table 'password'
            const hashedPassword = await bcrypt.hash(finalPassword, 10);
            const passwordQuery = 'INSERT INTO password (user_id, password) VALUES (?, ?)';
            await connection.query(passwordQuery, [userId, hashedPassword]);

            // Conditional profile generation logic for specialized professional roles
            if (role === 'professional') {
                const profileQuery = `
                    INSERT INTO professional_profiles (user_id, tagline, bio, city) 
                    VALUES (?, ?, ?, ?)
                `;
                await connection.query(profileQuery, [userId, tag_line, bio, city]);

                // Bulk insert selected relationship indices into 'professional_categories' mapping table
                if (categoryIds && categoryIds.length > 0) {
                    const categoryValues = categoryIds.map(catId => [userId, catId]);
                    const bulkCategoryQuery = 'INSERT INTO professional_categories (user_id, category_id) VALUES ?';
                    await connection.query(bulkCategoryQuery, [categoryValues]);
                }
            }

            // After inserting the values, delete from the temporary table
            const deletePendingQuery = 'DELETE FROM pending_registrations WHERE email = ?';
            await connection.query(deletePendingQuery, [email]);

            // Commit transaction parameters permanently to persistent storage disk rows
            await connection.commit();
            return userId;

        } catch (error) {
            // Rollback execution block parameters to preserve database sanity
            await connection.rollback();
            throw error;
        } finally {
            // Relinquish operational connection blueprint footprints back to pool allocation
            connection.release();
        }
    }

    // Login via email and encrypted password
    static async login(email) {
        const query = `
            SELECT u.id, u.email, u.name, u.role, u.profile_image_url, p.password 
            FROM users u
            JOIN password p ON u.id = p.user_id
            WHERE u.email = ?
        `;
        const [rows] = await pool.query(query, [email]);
        const user = rows[0];

        if (user) {
            // If the user is a professional, retrieve the categories
            if (user && user.role === 'professional') {
                user.categoryIds = await this.getProfessionalCategories(user.id);
            } else {
                user.categoryIds = [];
            }
        }

        return user;
    }

    // Retrieves user details by ID
    static async findById(id) {
        const query = 'SELECT id, email, name, role, profile_image_url FROM users WHERE id = ?';
        const [rows] = await pool.query(query, [id]);
        const user = rows[0];

        // If the user is a professional, retrieve the categories
        if (user && user.role === 'professional') {
            user.categoryIds = await this.getProfessionalCategories(user.id);
        } else {
            user.categoryIds = [];
        }

        return user;
    }

    static async getProfessionalCategories(userId) {
        const query = 'SELECT category_id FROM professional_categories WHERE user_id = ?';
        const [rows] = await pool.query(query, [userId]);
        // Converts an array of objects into a simple array of numbers.
        return rows.map(row => row.category_id);
    }
}

export default AuthModel;